// ============================================
// NOVA INTELLECT SCHOOL — Google Classroom API
// Récupère automatiquement tous les modules
// ============================================

const ClassroomAPI = {

  BASE_URL: 'https://classroom.googleapis.com/v1',

  // ── RÉCUPÉRER TOUS LES COURS ───────────────
  async getCourses(token) {
    const res = await this._fetch('/courses?courseStates=ACTIVE&teacherId=me', token);
    return res.courses || [];
  },

  // ── RÉCUPÉRER LES TRAVAUX (ÉTAPES) ─────────
  async getCourseWork(courseId, token) {
    const res = await this._fetch(`/courses/${courseId}/courseWork?orderBy=dueDate`, token);
    return res.courseWork || [];
  },

  // ── RÉCUPÉRER LES ANNONCES (INTRO MODULE) ──
  async getAnnouncements(courseId, token) {
    const res = await this._fetch(`/courses/${courseId}/announcements?orderBy=updateTime`, token);
    return res.announcements || [];
  },

  // ── RÉCUPÉRER LES MATÉRIAUX D'UN TRAVAIL ───
  async getMaterials(courseId, courseWorkId, token) {
    const res = await this._fetch(
      `/courses/${courseId}/courseWork/${courseWorkId}`, token
    );
    return res.materials || [];
  },

  // ── TRANSFORMER EN FORMAT NOVA ──────────────
  // Convertit les données Classroom → Structure interne
  async buildModules(token) {
    const courses = await this.getCourses(token);

    const modules = await Promise.all(courses.map(async (course, index) => {
      const [works, announcements] = await Promise.all([
        this.getCourseWork(course.id, token),
        this.getAnnouncements(course.id, token)
      ]);

      // Construire les étapes depuis les courseWork
      const steps = works.map((work, i) => {
        const materials = work.materials || [];
        const videoLink = materials.find(m => m.youtubeVideo)?.youtubeVideo?.alternateLink || null;
        const driveFile = materials.find(m => m.driveFile)?.driveFile || null;
        const linkMat   = materials.find(m => m.link)?.link || null;

        return {
          id:          work.id,
          courseId:    course.id,
          order:       i + 1,
          title:       work.title || `Étape ${i + 1}`,
          description: work.description || '',
          type:        videoLink ? 'video' : (driveFile ? 'pdf' : 'text'),
          videoUrl:    videoLink,
          pdfUrl:      driveFile?.driveFile?.alternateLink || null,
          pdfName:     driveFile?.driveFile?.title || null,
          linkUrl:     linkMat?.url || null,
          points:      work.maxPoints || null,
          dueDate:     work.dueDate || null,
          imagePrompt: work.title, // utilisé pour générer une image IA
          classroomUrl: work.alternateLink || null,
        };
      });

      // Description du module depuis la première annonce
      const description = announcements[0]?.text || course.description || '';

      // Icônes par index
      const icons = ['🤖', '🛠️', '🚀', '💡', '🎯', '⚡', '🌟', '🔥'];
      const colors = ['violet', 'blue', 'green', 'orange', 'pink', 'cyan', 'yellow', 'red'];

      return {
        id:          course.id,
        order:       index + 1,
        title:       course.name,
        description: description.substring(0, 150),
        icon:        icons[index % icons.length],
        colorKey:    colors[index % colors.length],
        totalSteps:  steps.length,
        steps:       steps,
        classroomId: course.id,
        classroomUrl: course.alternateLink,
        section:     course.section || null,
        room:        course.room || null,
      };
    }));

    // Trier par ordre / nom
    return modules.sort((a, b) => a.title.localeCompare(b.title));
  },

  // ── FETCH HELPER ───────────────────────────
  async _fetch(endpoint, token) {
    if (!token) throw new Error('Token Google manquant');

    const res = await fetch(`${this.BASE_URL}${endpoint}`, {
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    });

    if (res.status === 401) {
      // Token expiré → rediriger vers login
      window.location.href = 'index.html?reason=token_expired';
      throw new Error('Token expiré');
    }

    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.error?.message || `Erreur API ${res.status}`);
    }

    return res.json();
  },

  // ── CACHE LOCAL ────────────────────────────
  // Évite les appels répétés (valide 30 min)
  async getModulesCached(token) {
    const cacheKey = 'nova_modules_cache';
    const cacheTime = 'nova_modules_cache_time';
    const CACHE_DURATION = 30 * 60 * 1000; // 30 minutes

    const cached = localStorage.getItem(cacheKey);
    const cachedTime = localStorage.getItem(cacheTime);

    if (cached && cachedTime) {
      const age = Date.now() - parseInt(cachedTime);
      if (age < CACHE_DURATION) {
        return JSON.parse(cached);
      }
    }

    // Récupérer depuis l'API
    const modules = await this.buildModules(token);

    localStorage.setItem(cacheKey, JSON.stringify(modules));
    localStorage.setItem(cacheTime, Date.now().toString());

    return modules;
  },

  clearCache() {
    localStorage.removeItem('nova_modules_cache');
    localStorage.removeItem('nova_modules_cache_time');
  }
};

export default ClassroomAPI;
