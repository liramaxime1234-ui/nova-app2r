const CONFIG = {
  SUPABASE_URL:      'https://fvastjqqvvoecscatttc.supabase.co',
  SUPABASE_ANON_KEY: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImZ2YXN0anFxdnZvZWNzY2F0dHRjIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzE5ODcyMzYsImV4cCI6MjA4NzU2MzIzNn0.XugpxffFJih2ikBxpliVCXRNrnRj1nvZvXa4iz2DB20',
  GOOGLE_CLIENT_ID:  '142811964815-1p9ki6n93vbu3arkmmaequvspf3efrog.apps.googleusercontent.com',
  APP_NAME:    'NOVA Intellect School',
  APP_VERSION: '1.0.0',
  APP_URL:     window.location.origin,
  GOOGLE_SCOPES: 'https://www.googleapis.com/auth/classroom.courses.readonly https://www.googleapis.com/auth/classroom.coursework.students.readonly https://www.googleapis.com/auth/classroom.announcements.readonly https://www.googleapis.com/auth/drive.readonly profile email',
  ADMIN_EMAILS: ['liramaxime1234@gmail.com'],
  FEATURES: {
    chat: true,
    certificates: true,
    dark_mode: true,
    notifications: true,
  }
};

export default CONFIG;
