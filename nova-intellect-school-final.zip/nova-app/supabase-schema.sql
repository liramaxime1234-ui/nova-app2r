-- =============================================
-- NOVA INTELLECT SCHOOL — Supabase SQL Schema
-- Copiez-collez ce code dans :
-- Supabase > SQL Editor > New query > Run
-- =============================================

-- ── TABLE: PROFILES ───────────────────────────
CREATE TABLE IF NOT EXISTS profiles (
  id          UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name   TEXT,
  email       TEXT,
  avatar_url  TEXT,
  role        TEXT DEFAULT 'student',  -- 'student' ou 'admin'
  streak      INT DEFAULT 0,
  created_at  TIMESTAMPTZ DEFAULT NOW(),
  updated_at  TIMESTAMPTZ DEFAULT NOW()
);

-- ── TABLE: USER_PROGRESS ──────────────────────
CREATE TABLE IF NOT EXISTS user_progress (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id      UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  module_id    TEXT NOT NULL,
  step_id      TEXT NOT NULL,
  completed    BOOLEAN DEFAULT TRUE,
  completed_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, module_id, step_id)
);

-- ── TABLE: CERTIFICATES ───────────────────────
CREATE TABLE IF NOT EXISTS certificates (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id      UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  module_id    TEXT NOT NULL,
  module_name  TEXT NOT NULL,
  cert_id      TEXT UNIQUE NOT NULL,
  issued_at    TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, module_id)
);

-- ── TABLE: MESSAGES (CHAT) ────────────────────
CREATE TABLE IF NOT EXISTS messages (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  sender_id   UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  content     TEXT NOT NULL,
  module_id   TEXT,           -- Filtrage par module (optionnel)
  reply_to    UUID REFERENCES messages(id),
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- ── TABLE: NOTIFICATIONS ──────────────────────
CREATE TABLE IF NOT EXISTS notifications (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  title       TEXT NOT NULL,
  body        TEXT NOT NULL,
  type        TEXT DEFAULT 'info',  -- 'info', 'success', 'admin', 'certificate'
  read        BOOLEAN DEFAULT FALSE,
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- =============================================
-- AUTO-CREATE PROFILE WHEN USER SIGNS UP
-- =============================================
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (id, full_name, email, avatar_url)
  VALUES (
    NEW.id,
    NEW.raw_user_meta_data->>'full_name',
    NEW.email,
    NEW.raw_user_meta_data->>'avatar_url'
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- =============================================
-- ROW LEVEL SECURITY (RLS)
-- =============================================

ALTER TABLE profiles       ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_progress  ENABLE ROW LEVEL SECURITY;
ALTER TABLE certificates   ENABLE ROW LEVEL SECURITY;
ALTER TABLE messages       ENABLE ROW LEVEL SECURITY;
ALTER TABLE notifications  ENABLE ROW LEVEL SECURITY;

-- ── PROFILES ──────────────────────────────────
CREATE POLICY "profiles_select_own" ON profiles FOR SELECT USING (auth.uid() = id);
CREATE POLICY "profiles_update_own" ON profiles FOR UPDATE USING (auth.uid() = id);

-- Admin peut voir tous les profils
CREATE POLICY "profiles_admin_all" ON profiles FOR ALL
USING (auth.jwt()->>'email' = ANY(ARRAY['votre-email@gmail.com']));

-- ── USER_PROGRESS ─────────────────────────────
CREATE POLICY "progress_select_own" ON user_progress FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "progress_insert_own" ON user_progress FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "progress_update_own" ON user_progress FOR UPDATE USING (auth.uid() = user_id);

-- ── CERTIFICATES ──────────────────────────────
CREATE POLICY "certs_select_own"   ON certificates FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "certs_insert_own"   ON certificates FOR INSERT WITH CHECK (auth.uid() = user_id);

-- ── MESSAGES ──────────────────────────────────
CREATE POLICY "messages_select_all" ON messages FOR SELECT USING (TRUE);
CREATE POLICY "messages_insert_own" ON messages FOR INSERT WITH CHECK (auth.uid() = sender_id);

-- ── NOTIFICATIONS ─────────────────────────────
CREATE POLICY "notifs_select_own" ON notifications FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "notifs_update_own" ON notifications FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "notifs_insert_admin" ON notifications FOR INSERT
  WITH CHECK (auth.jwt()->>'email' = ANY(ARRAY['votre-email@gmail.com']));

-- =============================================
-- REALTIME (pour le chat en direct)
-- =============================================
ALTER PUBLICATION supabase_realtime ADD TABLE messages;
ALTER PUBLICATION supabase_realtime ADD TABLE notifications;

-- =============================================
-- INDEX (performance)
-- =============================================
CREATE INDEX IF NOT EXISTS idx_progress_user    ON user_progress(user_id);
CREATE INDEX IF NOT EXISTS idx_progress_module  ON user_progress(module_id);
CREATE INDEX IF NOT EXISTS idx_certs_user       ON certificates(user_id);
CREATE INDEX IF NOT EXISTS idx_messages_created ON messages(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_notifs_user      ON notifications(user_id);

-- ✅ DONE ! Votre base de données est prête.
-- Remplacez 'votre-email@gmail.com' par votre vrai email admin.
