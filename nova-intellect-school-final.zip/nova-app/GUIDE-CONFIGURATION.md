# 🚀 GUIDE DE CONFIGURATION — NOVA Intellect School

## ⏱ Temps estimé : 30 minutes

---

## ÉTAPE 1 — Créer votre compte Supabase (5 min)

1. Allez sur **https://supabase.com**
2. Cliquez **"Start your project"**
3. Connectez-vous avec GitHub ou email
4. Cliquez **"New project"**
5. Donnez un nom : `nova-intellect-school`
6. Choisissez un mot de passe fort
7. Cliquez **"Create new project"**

### Récupérer vos clés :
- Allez dans **Settings > API**
- Copiez :
  - `Project URL` → c'est votre `SUPABASE_URL`
  - `anon public` → c'est votre `SUPABASE_ANON_KEY`

---

## ÉTAPE 2 — Créer la base de données (3 min)

1. Dans Supabase, allez dans **SQL Editor**
2. Cliquez **"New query"**
3. Copiez tout le contenu du fichier `supabase-schema.sql`
4. Collez-le dans l'éditeur
5. ⚠️ **IMPORTANT** : Remplacez `votre-email@gmail.com` par votre vrai email
6. Cliquez **"Run"** (bouton vert)
7. Vous devriez voir "Success" ✅

---

## ÉTAPE 3 — Configurer Google OAuth dans Supabase (5 min)

1. Dans Supabase, allez **Authentication > Providers**
2. Trouvez **Google** et activez-le
3. Vous aurez besoin du `Client ID` et `Client Secret` Google (étape 4)
4. Dans **Redirect URLs**, ajoutez :
   - `http://localhost:3000` (pour les tests)
   - L'URL de votre hébergement final

---

## ÉTAPE 4 — Créer les identifiants Google Cloud (10 min)

1. Allez sur **https://console.cloud.google.com**
2. Créez un nouveau projet ou sélectionnez un existant
3. Cliquez sur **"APIs & Services" > "Bibliothèque"**
4. Cherchez et activez ces 2 APIs :
   - ✅ **Google Classroom API**
   - ✅ **Google Drive API**

5. Allez dans **"APIs & Services" > "Identifiants"**
6. Cliquez **"Créer des identifiants" > "ID client OAuth 2.0"**
7. Type d'application : **Application Web**
8. Nom : `NOVA Intellect School`
9. Ajoutez dans **"URI de redirection autorisés"** :
   - `https://VOTRE_SUPABASE_PROJECT.supabase.co/auth/v1/callback`
   (remplacez VOTRE_SUPABASE_PROJECT par votre ID)
10. Cliquez **"Créer"**
11. Copiez le **Client ID** et **Client Secret**

---

## ÉTAPE 5 — Mettre à jour config.js (2 min)

Ouvrez le fichier `config.js` et remplacez :

```javascript
SUPABASE_URL:    'https://VOTRE_ID.supabase.co',
SUPABASE_ANON_KEY: 'eyJhbGciOi...',
GOOGLE_CLIENT_ID: '123456789.apps.googleusercontent.com',
ADMIN_EMAILS: ['votre-email@gmail.com'],
```

---

## ÉTAPE 6 — Héberger l'application (5 min)

### Option A — Netlify (recommandé, gratuit)
1. Allez sur **https://netlify.com**
2. Glissez-déposez votre dossier `nova-app`
3. Votre app est en ligne en 1 minute !
4. Copiez l'URL et ajoutez-la dans :
   - Google Cloud Console (URI de redirection)
   - Supabase (URL du site)

### Option B — GitHub Pages (gratuit)
1. Créez un dépôt GitHub
2. Uploadez tous les fichiers
3. Activez GitHub Pages dans Settings

### Option C — Sur votre téléphone (pour tester)
Utilisez l'extension VS Code **Live Server** ou **http-server**

---

## ÉTAPE 7 — Configurer Google Classroom (2 min)

1. Assurez-vous que vos cours Google Classroom sont actifs
2. Connectez-vous à l'app avec votre compte Google (le même que Classroom)
3. Lors de la première connexion, acceptez les permissions demandées
4. Les modules seront automatiquement importés !

---

## ✅ CHECKLIST FINALE

- [ ] Compte Supabase créé
- [ ] Base de données créée (SQL schema exécuté)
- [ ] Google OAuth configuré dans Supabase
- [ ] APIs Google Classroom activées
- [ ] Identifiants OAuth créés
- [ ] `config.js` mis à jour
- [ ] App hébergée
- [ ] Première connexion testée
- [ ] Modules Classroom visibles

---

## 📁 LISTE DES FICHIERS

```
nova-app/
├── index.html          → Splash + Login
├── dashboard.html      → Tableau de bord
├── module.html         → Détail d'un module
├── lesson.html         → Leçon (vidéo/PDF/texte)
├── certificate.html    → Certificats automatiques
├── chat.html           → Chat communauté
├── admin.html          → Panel administrateur
├── profile.html        → Profil utilisateur
├── register.html       → Inscription
├── style.css           → Design complet
├── config.js           → ⚡ À CONFIGURER !
├── supabase.js         → Client Supabase
├── classroom.js        → API Google Classroom
├── app.js              → Logique principale
└── supabase-schema.sql → Base de données SQL
```

---

## 🆘 PROBLÈMES FRÉQUENTS

**"Invalid API key"** → Vérifiez votre `SUPABASE_ANON_KEY` dans config.js

**"Modules ne chargent pas"** → Assurez-vous d'être connecté avec le compte Google qui a les cours

**"Erreur OAuth"** → Vérifiez que l'URL de redirection est correcte dans Google Cloud Console

**"Aucun module trouvé"** → Vérifiez que vos cours Classroom sont en état "ACTIF"

---

## 📞 SUPPORT

En cas de problème, vérifiez :
1. La console du navigateur (F12 > Console)
2. Les logs Supabase (Authentication > Logs)
3. Les restrictions API Google Cloud (quota non dépassé)

---

*NOVA Intellect School v1.0 — Configuration Guide*
