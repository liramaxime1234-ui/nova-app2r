// ============================================
// NOVA INTELLECT SCHOOL — Supabase Client
// ============================================

import CONFIG from './config.js';

// ── INITIALISATION SUPABASE ──────────────────
const { createClient } = window.supabase;
const db = createClient(CONFIG.SUPABASE_URL, CONFIG.SUPABASE_ANON_KEY);

// ── AUTH HELPERS ─────────────────────────────

const Auth = {

  // Connexion Google OAuth
  async loginWithGoogle() {
    const { data, error } = await db.auth.signInWithOAuth({
      provider: 'google',
      options: {
        scopes: CONFIG.GOOGLE_SCOPES,
        redirectTo: CONFIG.APP_URL + '/dashboard.html',
        queryParams: {
          access_type: 'offline',
          prompt: 'consent',
        }
      }
    });
    if (error) throw error;
    return data;
  },

  // Connexion Email + Mot de passe
  async loginWithEmail(email, password) {
    const { data, error } = await db.auth.signInWithPassword({ email, password });
    if (error) throw error;
    return data;
  },

  // Inscription Email + Mot de passe
  async registerWithEmail(email, password, fullName) {
    const { data, error } = await db.auth.signUp({
      email, password,
      options: { data: { full_name: fullName } }
    });
    if (error) throw error;
    return data;
  },

  // Mot de passe oublié
  async resetPassword(email) {
    const { error } = await db.auth.resetPasswordForEmail(email, {
      redirectTo: CONFIG.APP_URL + '/reset-password.html'
    });
    if (error) throw error;
  },

  // Déconnexion
  async logout() {
    const { error } = await db.auth.signOut();
    if (error) throw error;
    window.location.href = 'index.html';
  },

  // Utilisateur courant
  async getCurrentUser() {
    const { data: { user } } = await db.auth.getUser();
    return user;
  },

  // Écouter les changements d'auth
  onAuthChange(callback) {
    return db.auth.onAuthStateChange((event, session) => {
      callback(event, session);
    });
  },

  // Vérifier si admin
  isAdmin(user) {
    if (!user) return false;
    return CONFIG.ADMIN_EMAILS.includes(user.email);
  },

  // Token Google (pour appels Classroom API)
  async getGoogleToken() {
    const { data: { session } } = await db.auth.getSession();
    return session?.provider_token || null;
  }
};

// ── USER PROFILE ─────────────────────────────

const UserProfile = {

  async get(userId) {
    const { data, error } = await db
      .from('profiles')
      .select('*')
      .eq('id', userId)
      .single();
    if (error) return null;
    return data;
  },

  async update(userId, updates) {
    const { data, error } = await db
      .from('profiles')
      .upsert({ id: userId, ...updates, updated_at: new Date().toISOString() });
    if (error) throw error;
    return data;
  },

  async getProgress(userId) {
    const { data, error } = await db
      .from('user_progress')
      .select('*')
      .eq('user_id', userId);
    if (error) return [];
    return data;
  },

  async markStepDone(userId, moduleId, stepId) {
    const { data, error } = await db
      .from('user_progress')
      .upsert({
        user_id: userId,
        module_id: moduleId,
        step_id: stepId,
        completed: true,
        completed_at: new Date().toISOString()
      });
    if (error) throw error;

    // Vérifier si le module est terminé pour générer le certificat
    await Certificates.checkAndGenerate(userId, moduleId);

    return data;
  },

  async getCompletedSteps(userId) {
    const { data } = await db
      .from('user_progress')
      .select('step_id, module_id')
      .eq('user_id', userId)
      .eq('completed', true);
    return data || [];
  }
};

// ── CERTIFICATES ─────────────────────────────

const Certificates = {

  async getAll(userId) {
    const { data, error } = await db
      .from('certificates')
      .select('*')
      .eq('user_id', userId)
      .order('issued_at', { ascending: false });
    if (error) return [];
    return data;
  },

  async checkAndGenerate(userId, moduleId) {
    // Compter les étapes du module vs étapes complétées
    const modules = window.AppState?.modules || [];
    const mod = modules.find(m => m.id === moduleId);
    if (!mod) return;

    const completed = await UserProfile.getCompletedSteps(userId);
    const moduleCompleted = completed.filter(s => s.module_id === moduleId);

    if (mod.totalSteps && moduleCompleted.length >= mod.totalSteps) {
      await this.generate(userId, moduleId, mod.title);
    }
  },

  async generate(userId, moduleId, moduleName) {
    // Vérifier si existe déjà
    const { data: existing } = await db
      .from('certificates')
      .select('id')
      .eq('user_id', userId)
      .eq('module_id', moduleId)
      .single();

    if (existing) return existing;

    const certId = 'NOVA-' + new Date().getFullYear() + '-' + Math.random().toString(36).substr(2, 6).toUpperCase();

    const { data, error } = await db
      .from('certificates')
      .insert({
        user_id: userId,
        module_id: moduleId,
        module_name: moduleName,
        cert_id: certId,
        issued_at: new Date().toISOString()
      })
      .select()
      .single();

    if (!error && data) {
      window.showToast('🎓', 'Félicitations !', 'Votre certificat est disponible !');
    }

    return data;
  }
};

// ── CHAT ─────────────────────────────────────

const Chat = {

  async getMessages(limit = 50) {
    const { data, error } = await db
      .from('messages')
      .select(`
        *,
        profiles:sender_id (full_name, avatar_url)
      `)
      .order('created_at', { ascending: false })
      .limit(limit);
    if (error) return [];
    return data.reverse();
  },

  async send(userId, text, moduleId = null) {
    const { data, error } = await db
      .from('messages')
      .insert({
        sender_id: userId,
        content: text,
        module_id: moduleId,
        created_at: new Date().toISOString()
      })
      .select()
      .single();
    if (error) throw error;
    return data;
  },

  subscribe(callback) {
    return db
      .channel('messages')
      .on('postgres_changes', {
        event: 'INSERT',
        schema: 'public',
        table: 'messages'
      }, callback)
      .subscribe();
  }
};

// ── NOTIFICATIONS ────────────────────────────

const Notifications = {

  async getAll(userId) {
    const { data, error } = await db
      .from('notifications')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false })
      .limit(20);
    if (error) return [];
    return data;
  },

  async markRead(notifId) {
    await db.from('notifications').update({ read: true }).eq('id', notifId);
  },

  async getUnreadCount(userId) {
    const { count } = await db
      .from('notifications')
      .select('*', { count: 'exact', head: true })
      .eq('user_id', userId)
      .eq('read', false);
    return count || 0;
  }
};

export { db, Auth, UserProfile, Certificates, Chat, Notifications };
