// ============================================
// NOVA INTELLECT SCHOOL — App State & Utils
// ============================================

import { Auth, UserProfile, Certificates } from './supabase.js';
import ClassroomAPI from './classroom.js';

// ── APP STATE ────────────────────────────────
window.AppState = {
  user:             null,
  profile:          null,
  modules:          [],
  completedSteps:   [],
  certificates:     [],
  currentModuleId:  null,
  currentStepId:    null,
  isAdmin:          false,
  googleToken:      null,
  isLoading:        false,
};

// ── INIT APP ─────────────────────────────────
async function initApp() {
  // Écouter les changements d'auth
  Auth.onAuthChange(async (event, session) => {
    if (event === 'SIGNED_IN' && session) {
      AppState.user = session.user;
      AppState.googleToken = session.provider_token;
      AppState.isAdmin = Auth.isAdmin(session.user);

      // Charger le profil
      AppState.profile = await UserProfile.get(session.user.id);

      // Charger la progression
      AppState.completedSteps = await UserProfile.getCompletedSteps(session.user.id);

      // Charger les modules depuis Classroom
      if (AppState.googleToken) {
        try {
          AppState.modules = await ClassroomAPI.getModulesCached(AppState.googleToken);
        } catch(e) {
          console.warn('Classroom API error:', e);
          AppState.modules = getFallbackModules();
        }
      }

    } else if (event === 'SIGNED_OUT') {
      AppState.user = null;
      AppState.profile = null;
      AppState.modules = [];
      AppState.completedSteps = [];
    }
  });
}

// ── NAVIGATION ───────────────────────────────
function navigate(page, params = {}) {
  const url = new URL(page, window.location.origin);
  Object.entries(params).forEach(([k, v]) => url.searchParams.set(k, v));
  window.location.href = url.toString();
}

function getParam(name) {
  return new URLSearchParams(window.location.search).get(name);
}

// ── PROGRESS HELPERS ─────────────────────────
function isStepDone(stepId) {
  return AppState.completedSteps.some(s => s.step_id === stepId);
}

function getModuleProgress(moduleId) {
  const mod = AppState.modules.find(m => m.id === moduleId);
  if (!mod || mod.totalSteps === 0) return 0;
  const done = AppState.completedSteps.filter(s => s.module_id === moduleId).length;
  return Math.round((done / mod.totalSteps) * 100);
}

function isModuleLocked(moduleIndex) {
  if (moduleIndex === 0) return false;
  const prevMod = AppState.modules[moduleIndex - 1];
  if (!prevMod) return false;
  const progress = getModuleProgress(prevMod.id);
  return progress < 100;
}

function isStepLocked(moduleId, stepIndex) {
  if (stepIndex === 0) return false;
  const mod = AppState.modules.find(m => m.id === moduleId);
  if (!mod) return true;
  const prevStep = mod.steps[stepIndex - 1];
  if (!prevStep) return true;
  return !isStepDone(prevStep.id);
}

function getTotalProgress() {
  const total = AppState.modules.reduce((acc, m) => acc + m.totalSteps, 0);
  if (total === 0) return 0;
  return Math.round((AppState.completedSteps.length / total) * 100);
}

// ── TOAST ────────────────────────────────────
let toastTimer = null;

window.showToast = function(icon, title, message, duration = 3500) {
  let container = document.getElementById('toast-container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toast-container';
    container.className = 'toast-container';
    document.body.appendChild(container);
  }

  const toast = document.createElement('div');
  toast.className = 'toast';
  toast.innerHTML = `
    <span class="toast-icon">${icon}</span>
    <div class="toast-content">
      <div class="toast-title">${title}</div>
      ${message ? `<div class="toast-msg">${message}</div>` : ''}
    </div>
  `;

  container.appendChild(toast);
  requestAnimationFrame(() => toast.classList.add('show'));

  setTimeout(() => {
    toast.classList.remove('show');
    setTimeout(() => toast.remove(), 400);
  }, duration);
};

// ── FORMAT HELPERS ───────────────────────────
function formatDate(isoString) {
  if (!isoString) return '';
  return new Date(isoString).toLocaleDateString('fr-FR', {
    day: 'numeric', month: 'long', year: 'numeric'
  });
}

function formatTime(isoString) {
  if (!isoString) return '';
  return new Date(isoString).toLocaleTimeString('fr-FR', {
    hour: '2-digit', minute: '2-digit'
  });
}

function initials(name) {
  if (!name) return '?';
  return name.split(' ').map(n => n[0]).join('').toUpperCase().substring(0, 2);
}

function truncate(str, len = 80) {
  if (!str) return '';
  return str.length > len ? str.substring(0, len) + '…' : str;
}

// ── COLOR MAP ───────────────────────────────
const COLOR_MAP = {
  violet: { bg: 'rgba(124,58,237,0.15)', text: '#A78BFA' },
  blue:   { bg: 'rgba(59,130,246,0.15)',  text: '#93C5FD' },
  green:  { bg: 'rgba(16,185,129,0.15)',  text: '#6EE7B7' },
  orange: { bg: 'rgba(245,158,11,0.15)',  text: '#FCD34D' },
  pink:   { bg: 'rgba(236,72,153,0.15)',  text: '#F9A8D4' },
  cyan:   { bg: 'rgba(6,182,212,0.15)',   text: '#67E8F9' },
};

function getColor(key) {
  return COLOR_MAP[key] || COLOR_MAP.violet;
}

// ── FALLBACK (si Classroom indisponible) ─────
function getFallbackModules() {
  return [
    {
      id: 'mod_1', order: 1,
      title: "Module 1 : Découvrir l'IA",
      description: "Explorez les fondamentaux de l'intelligence artificielle.",
      icon: '🤖', colorKey: 'violet', totalSteps: 6,
      steps: [
        { id: 's1', order: 1, title: 'Faisons connaissance', type: 'video', description: 'Bienvenue dans NOVA Intellect School' },
        { id: 's2', order: 2, title: "Qu'est-ce que l'IA ?", type: 'video', description: 'Définitions et concepts fondamentaux' },
        { id: 's3', order: 3, title: "Pourquoi utiliser l'IA ?", type: 'pdf', description: 'Avantages et cas d\'usage réels' },
        { id: 's4', order: 4, title: 'Outils IA essentiels', type: 'video', description: 'ChatGPT, Gemini, Claude et autres' },
        { id: 's5', order: 5, title: 'Installation & Setup', type: 'pdf', description: 'Configuration de votre environnement' },
        { id: 's6', order: 6, title: 'Démonstration pratique', type: 'video', description: 'Exercice guidé pas à pas' },
      ]
    }
  ];
}

// ── IMAGE IA (Unsplash for topic images) ─────
function getStepImage(title) {
  // Retourne une image Unsplash pertinente basée sur le titre
  const topics = {
    'ia': 'artificial-intelligence',
    'intelligence': 'technology',
    'outil': 'tools',
    'installation': 'computer',
    'démonstration': 'presentation',
    'pratique': 'learning',
    'python': 'programming',
    'données': 'data',
    'image': 'digital-art',
    'texte': 'writing',
  };

  const lower = title.toLowerCase();
  let keyword = 'technology';

  for (const [key, val] of Object.entries(topics)) {
    if (lower.includes(key)) { keyword = val; break; }
  }

  // Unsplash source avec seed pour cohérence
  const seed = title.length + title.charCodeAt(0);
  return `https://source.unsplash.com/800x400/?${keyword},ai&sig=${seed}`;
}

export {
  initApp, navigate, getParam,
  isStepDone, getModuleProgress, isModuleLocked, isStepLocked, getTotalProgress,
  formatDate, formatTime, initials, truncate, getColor, getStepImage,
  getFallbackModules
};
